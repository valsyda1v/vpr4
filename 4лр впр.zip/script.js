// Масив даних (імітація бази даних)
const toursData = [
    { id: 1, title: "Шарм-ель-Шейх", destination: "Єгипет", price: 25000, img: "1.png" },
    { id: 2, title: "Анталія", destination: "Туреччина", price: 22000, img: "2.png" },
    { id: 3, title: "Париж", destination: "Франція", price: 35000, img: "3.png" },
    { id: 4, title: "Будва", destination: "Чорногорія", price: 18500, img: "4.png" },
    { id: 5, title: "Марса-Алам", destination: "Єгипет", price: 30000, img: "1.png" },
    { id: 6, title: "Стамбул", destination: "Туреччина", price: 15000, img: "2.png" }
];

// Вибірка елементів DOM
const destinationSelect = document.querySelector('#destination-select');
const priceRange = document.querySelector('#price-range');
const priceValueDisplay = document.querySelector('#price-value');
const resultsCount = document.querySelector('#results-count');
const toursContainer = document.querySelector('#tours-container');

// Функція рендеру карток
function renderTours(tours) {
    toursContainer.innerHTML = ''; // Очищення контейнера
    
    if (tours.length === 0) {
        toursContainer.innerHTML = '<p class="no-results">Тури за вказаними параметрами не знайдені.</p>';
        resultsCount.textContent = '0';
        return;
    }

    tours.forEach(tour => {
        const card = document.createElement('div');
        card.className = 'card';
        card.innerHTML = `
            <img src="${tour.img}" alt="${tour.title}" style="max-width:100%">
            <h3>${tour.title}</h3>
            <p>Напрямок: ${tour.destination}</p>
            <p><strong>Ціна: ${tour.price} грн</strong></p>
        `;
        toursContainer.appendChild(card);
    });

    resultsCount.textContent = tours.length; // Оновлення лічильника результатів 
}

// 4. Функція фільтрації (Основна логіка)
function filterTours() {
    const selectedDestination = destinationSelect.value;
    const maxPrice = parseInt(priceRange.value);

    // Оновлення тексту ціни поруч із повзунком
    priceValueDisplay.textContent = maxPrice;

    // Подвійний фільтр масиву 
    const filtered = toursData.filter(tour => {
        const matchDestination = selectedDestination === 'all' || tour.destination === selectedDestination;
        const matchPrice = tour.price <= maxPrice;
        return matchDestination && matchPrice;
    });

    renderTours(filtered);
}

// 5. Реєстрація обробників подій
destinationSelect.addEventListener('change', filterTours); // Подія change 
priceRange.addEventListener('input', filterTours);       // Подія input 

// Початковий рендер при завантаженні сторінки
document.addEventListener('DOMContentLoaded', () => {
    renderTours(toursData);
});